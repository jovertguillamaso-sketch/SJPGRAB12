import { useState } from "react";

export default function ProductImage({ food }) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return <div className="food-fallback">{food.emoji}</div>;
  }

  return (
    <img
      className="food-photo"
      src={food.image}
      alt={food.name}
      onError={() => setFailed(true)}
    />
  );
}
