export const stores = {
  "Ibyong Store": [
    { id: 1, name: "Chicken Meal", price: 65, image: "/products/chicken-meal.jpg", emoji: "🍗" },
    { id: 2, name: "Burger", price: 45, image: "/products/burger.jpg", emoji: "🍔" },
    { id: 3, name: "French Fries", price: 35, image: "/products/fries.jpg", emoji: "🍟" },
    { id: 4, name: "Siomai", price: 30, image: "/products/siomai.jpg", emoji: "🥟" },
    { id: 5, name: "Iced Tea", price: 25, image: "/products/iced-tea.jpg", emoji: "🥤" },
  ],
  "Santos Store": [
    { id: 6, name: "Pancit Canton", price: 45, image: "/products/pancit-canton.jpg", emoji: "🍜" },
    { id: 7, name: "Hotdog Sandwich", price: 40, image: "/products/hotdog.jpg", emoji: "🌭" },
    { id: 8, name: "Fried Chicken", price: 55, image: "/products/fried-chicken.jpg", emoji: "🍗" },
    { id: 9, name: "Lumpia", price: 30, image: "/products/lumpia.jpg", emoji: "🥢" },
    { id: 10, name: "Milk Tea", price: 50, image: "/products/milk-tea.jpg", emoji: "🧋" },
  ],
};
