import { useState } from "react";
import "./App.css";
import { stores } from "./data/stores";
import { money } from "./utils/money";
import ProductImage from "./components/ProductImage";







function App() {
  const [page, setPage] = useState("login");
  const [user, setUser] = useState(null);
  const [accounts, setAccounts] = useState([]);

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [authMessage, setAuthMessage] = useState("");

  const [store, setStore] = useState("Ibyong Store");
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [building, setBuilding] = useState("");
  const [floor, setFloor] = useState("");
  const [instructions, setInstructions] = useState("");
  const [payment, setPayment] = useState("Cash");
  const [cashReceived, setCashReceived] = useState("");
  const [checkoutError, setCheckoutError] = useState("");
  const [receipt, setReceipt] = useState(null);
  const [orders, setOrders] = useState([]);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const itemCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const change =
    cashReceived !== "" && Number(cashReceived) >= total
      ? Number(cashReceived) - total
      : 0;

  const createAccount = (event) => {
    event.preventDefault();
    setAuthMessage("");

    if (!signupName.trim() || !signupEmail.trim() || !signupPassword) {
      setAuthMessage("Please complete all fields.");
      return;
    }

    if (signupPassword !== confirmPassword) {
      setAuthMessage("Passwords do not match.");
      return;
    }

    if (accounts.some((account) => account.email === signupEmail.trim().toLowerCase())) {
      setAuthMessage("An account with this email already exists.");
      return;
    }

    const newAccount = {
      name: signupName.trim(),
      email: signupEmail.trim().toLowerCase(),
      password: signupPassword,
    };

    setAccounts((previous) => [...previous, newAccount]);
    setLoginEmail(newAccount.email);
    setLoginPassword("");
    setSignupName("");
    setSignupEmail("");
    setSignupPassword("");
    setConfirmPassword("");
    setAuthMessage("Account created. Please log in.");
    setPage("login");
  };

  const login = (event) => {
    event.preventDefault();
    setAuthMessage("");

    const account = accounts.find(
      (item) =>
        item.email === loginEmail.trim().toLowerCase() &&
        item.password === loginPassword
    );

    if (!account) {
      setAuthMessage("Account not found or password is incorrect. Please sign up first.");
      return;
    }

    setUser(account);
    setCustomerName(account.name);
    setPage("dashboard");
  };

  const addToCart = (food) => {
    setCheckoutError("");
    setCart((previous) => {
      const existing = previous.find((item) => item.id === food.id);

      if (existing) {
        return previous.map((item) =>
          item.id === food.id ? { ...item, qty: item.qty + 1 } : item
        );
      }

      return [...previous, { ...food, qty: 1 }];
    });
  };

  const changeQty = (id, amount) => {
    setCart((previous) =>
      previous
        .map((item) =>
          item.id === id ? { ...item, qty: item.qty + amount } : item
        )
        .filter((item) => item.qty > 0)
    );
  };

  const placeOrder = (event) => {
    event.preventDefault();
    setCheckoutError("");

    if (!customerName.trim() || !building.trim() || !floor.trim()) {
      setCheckoutError("Please enter the customer's name, building, and floor.");
      return;
    }

    if (cart.length === 0) {
      setCheckoutError("Your cart is empty. Add food before placing an order.");
      return;
    }

    const orderTotal = cart.reduce(
      (sum, item) => sum + item.price * item.qty,
      0
    );

    const paid = payment === "Cash" ? Number(cashReceived) : orderTotal;

    if (payment === "Cash" && cashReceived.trim() === "") {
      setCheckoutError("Enter the cash amount received.");
      return;
    }

    if (!Number.isFinite(paid) || paid < orderTotal) {
      setCheckoutError("Cash received must be equal to or greater than the total.");
      return;
    }

    const newOrder = {
      orderNumber: `CG-${Date.now().toString().slice(-8)}`,
      date: new Date().toLocaleString(),
      customerName: customerName.trim(),
      email: user?.email || "",
      building: building.trim(),
      floor: floor.trim(),
      instructions: instructions.trim(),
      store,
      payment,
      items: cart.map((item) => ({ ...item })),
      subtotal: orderTotal,
      amountPaid: paid,
      change: payment === "Cash" ? paid - orderTotal : 0,
    };

    setReceipt(newOrder);
    setOrders((previous) => [newOrder, ...previous]);
    setCart([]);
    setCashReceived("");
    setInstructions("");
    setCheckoutError("");
  };

  const logout = () => {
    setPage("login");
    setUser(null);
    setCart([]);
    setReceipt(null);
    setSettingsOpen(false);
    setAuthMessage("");
    setCheckoutError("");
  };

  if (page === "login" || page === "signup") {
    const signingUp = page === "signup";

    return (
      <div className="auth-screen">
        <div className="auth-decoration decoration-one" />
        <div className="auth-decoration decoration-two" />

        <div className="auth-layout">
          <section className="auth-hero">
            <div className="brand-lockup">
              <div className="brand-logo">
                <img src="/logo.png" alt="Canteen Grab logo" />
              </div>
              <div>
                <strong>CANTEEN GRAB</strong>
                <span>CAMPUS FOOD DELIVERY</span>
              </div>
            </div>

            <div className="hero-copy">
              <span className="eyebrow">YOUR CAMPUS. YOUR FOOD.</span>
              <h1>
                GOOD FOOD.
                <br />
                <span>ZERO HASSLE.</span>
              </h1>
              <p>
                Your favorite campus meals, just a few clicks away.
                Order, pay, and get back to what matters.
              </p>
              <div className="hero-features">
                <span>01 / CHOOSE FOOD</span>
                <span>02 / PLACE ORDER</span>
                <span>03 / ENJOY</span>
              </div>
            </div>

            <div className="hero-bottom">
              <span>FRESH • FAST • CAMPUS</span>
              <span>EST. 2026</span>
            </div>
          </section>

          <section className="auth-side">
            <form
              className="auth-card"
              onSubmit={signingUp ? createAccount : login}
            >
              <div className="auth-card-logo">
                <img src="/logo.png" alt="Logo" />
              </div>

              <span className="eyebrow">
                {signingUp ? "BECOME A MEMBER" : "WELCOME BACK"}
              </span>
              <h2>{signingUp ? "Create account." : "Let's eat."}</h2>
              <p className="auth-description">
                {signingUp
                  ? "Sign up to start ordering your favorites."
                  : "Log in to your account to continue."}
              </p>

              {signingUp && (
                <label className="field">
                  <span>Full name</span>
                  <input
                    value={signupName}
                    onChange={(event) => setSignupName(event.target.value)}
                    placeholder="Your full name"
                    autoComplete="name"
                    required
                  />
                </label>
              )}

              <label className="field">
                <span>Email address</span>
                <input
                  type="email"
                  value={signingUp ? signupEmail : loginEmail}
                  onChange={(event) =>
                    signingUp
                      ? setSignupEmail(event.target.value)
                      : setLoginEmail(event.target.value)
                  }
                  placeholder="you@example.com"
                  autoComplete="email"
                  required
                />
              </label>

              <label className="field">
                <span>Password</span>
                <input
                  type="password"
                  value={signingUp ? signupPassword : loginPassword}
                  onChange={(event) =>
                    signingUp
                      ? setSignupPassword(event.target.value)
                      : setLoginPassword(event.target.value)
                  }
                  placeholder="Enter your password"
                  autoComplete={signingUp ? "new-password" : "current-password"}
                  required
                />
              </label>

              {signingUp && (
                <label className="field">
                  <span>Confirm password</span>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(event) => setConfirmPassword(event.target.value)}
                    placeholder="Confirm your password"
                    autoComplete="new-password"
                    required
                  />
                </label>
              )}

              {authMessage && <div className="notice">{authMessage}</div>}

              <button className="primary-button auth-submit" type="submit">
                {signingUp ? "CREATE ACCOUNT" : "LOG IN"}
                <span>→</span>
              </button>

              <p className="auth-switch">
                {signingUp ? "Already registered?" : "New to Canteen Grab?"}{" "}
                <button
                  type="button"
                  onClick={() => {
                    setAuthMessage("");
                    setPage(signingUp ? "login" : "signup");
                  }}
                >
                  {signingUp ? "Log in" : "Create account"}
                </button>
              </p>
            </form>
          </section>
        </div>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-logo">
            <img src="/logo.png" alt="Canteen Grab logo" />
          </div>
          <div>
            <strong>CANTEEN GRAB</strong>
            <span>ORDERING SYSTEM</span>
          </div>
        </div>

        <div className="topbar-actions">
          <div className="online-status">
            <span />
            CUSTOMER PORTAL
          </div>
          <button
            className="secondary-button"
            onClick={() => setSettingsOpen((open) => !open)}
          >
            ⚙ Settings
          </button>
          <button className="logout-button" onClick={logout}>
            Log out
          </button>
        </div>
      </header>

      {settingsOpen && (
        <section className="settings-panel">
          <div>
            <span className="eyebrow">ACCOUNT SETTINGS</span>
            <h3>Your profile</h3>
            <p>{user?.name}</p>
            <p>{user?.email}</p>
          </div>
          <button
            className="secondary-button"
            onClick={() => setSettingsOpen(false)}
          >
            Close
          </button>
        </section>
      )}

      <main className="main-content">
        <section className="welcome-row">
          <div>
            <span className="eyebrow">CANTEEN / FOOD ORDERING</span>
            <h1>
              What's on your <span>menu?</span>
            </h1>
            <p>Choose your store, pick your favorites, and order with ease.</p>
          </div>
          <div className="cart-summary">
            <span className="cart-summary-icon">🛒</span>
            <div>
              <strong>{itemCount}</strong>
              <span>ITEMS IN CART</span>
            </div>
          </div>
        </section>

        <section className="store-section">
          <div className="section-heading">
            <span className="section-number">01</span>
            <div>
              <h2>Select a store</h2>
              <p>Choose where you want to order from.</p>
            </div>
          </div>

          <div className="store-tabs">
            {Object.keys(stores).map((storeName) => (
              <button
                key={storeName}
                className={store === storeName ? "store-tab active" : "store-tab"}
                onClick={() => setStore(storeName)}
              >
                <span>▦</span> {storeName}
              </button>
            ))}
          </div>
        </section>

        <section className="food-grid">
          {stores[store].map((food) => (
            <article className="food-card" key={food.id}>
              <div className="food-image-wrap">
                <ProductImage food={food} />
                <span className="fresh-tag">AVAILABLE</span>
              </div>
              <div className="food-card-body">
                <span className="food-store">{store}</span>
                <h3>{food.name}</h3>
                <div className="food-card-bottom">
                  <strong>{money(food.price)}</strong>
                  <button
                    className="add-button"
                    onClick={() => addToCart(food)}
                    aria-label={`Add ${food.name} to cart`}
                  >
                    + Add
                  </button>
                </div>
              </div>
            </article>
          ))}
        </section>

        <section className="checkout-layout">
          <form className="delivery-panel" onSubmit={placeOrder}>
            <div className="section-heading">
              <span className="section-number">02</span>
              <div>
                <h2>Delivery information</h2>
                <p>Where should we deliver your food?</p>
              </div>
            </div>

            <div className="form-grid">
              <label className="field">
                <span>Customer name</span>
                <input
                  value={customerName}
                  onChange={(event) => setCustomerName(event.target.value)}
                  placeholder="Enter full name"
                  required
                />
              </label>

              <label className="field">
                <span>Building</span>
                <input
                  value={building}
                  onChange={(event) => setBuilding(event.target.value)}
                  placeholder="Building name"
                  required
                />
              </label>

              <label className="field">
                <span>Floor / Room</span>
                <input
                  value={floor}
                  onChange={(event) => setFloor(event.target.value)}
                  placeholder="e.g. 2nd floor, Room 204"
                  required
                />
              </label>

              <label className="field">
                <span>Payment method</span>
                <select
                  value={payment}
                  onChange={(event) => {
                    setPayment(event.target.value);
                    setCashReceived("");
                    setCheckoutError("");
                  }}
                >
                  <option value="Cash">Cash</option>
                  <option value="GCash">GCash</option>
                </select>
              </label>

              <label className="field full-field">
                <span>Special instructions</span>
                <textarea
                  value={instructions}
                  onChange={(event) => setInstructions(event.target.value)}
                  placeholder="Delivery instructions (optional)"
                  rows="3"
                />
              </label>
            </div>
          </form>

          <aside className="cart-panel">
            <div className="cart-panel-heading">
              <div>
                <span className="eyebrow">ORDER DETAILS</span>
                <h2>Your cart</h2>
              </div>
              <span className="cart-count">{itemCount}</span>
            </div>

            {cart.length === 0 ? (
              <div className="empty-cart">
                <span>🛒</span>
                <h3>Your cart is empty</h3>
                <p>Add food from the menu to begin your order.</p>
              </div>
            ) : (
              <>
                <div className="cart-items">
                  {cart.map((item) => (
                    <div className="cart-item" key={item.id}>
                      <div className="cart-item-info">
                        <strong>{item.emoji} {item.name}</strong>
                        <span>{money(item.price)} each</span>
                      </div>
                      <div className="quantity-control">
                        <button
                          type="button"
                          onClick={() => changeQty(item.id, -1)}
                          aria-label={`Remove one ${item.name}`}
                        >
                          −
                        </button>
                        <strong>{item.qty}</strong>
                        <button
                          type="button"
                          onClick={() => changeQty(item.id, 1)}
                          aria-label={`Add one ${item.name}`}
                        >
                          +
                        </button>
                      </div>
                      <strong className="cart-line-total">
                        {money(item.price * item.qty)}
                      </strong>
                    </div>
                  ))}
                </div>

                <div className="cart-total">
                  <span>Total to pay</span>
                  <strong>{money(total)}</strong>
                </div>

                {payment === "Cash" && (
                  <div className="cash-payment">
                    <label className="field">
                      <span>Cash received (₱)</span>
                      <input
                        type="number"
                        min={total}
                        step="0.01"
                        value={cashReceived}
                        onChange={(event) => {
                          setCashReceived(event.target.value);
                          setCheckoutError("");
                        }}
                        placeholder={`At least ${total.toFixed(2)}`}
                      />
                    </label>
                    <div className="change-preview">
                      <span>Customer change</span>
                      <strong>{money(change)}</strong>
                    </div>
                  </div>
                )}

                {payment === "GCash" && (
                  <div className="payment-note">
                    GCash selected. This demo records the order as paid; it
                    does not process a real GCash transaction.
                  </div>
                )}

                {checkoutError && (
                  <div className="checkout-error">{checkoutError}</div>
                )}

                <button
                  className="primary-button place-order-button"
                  type="button"
                  onClick={placeOrder}
                >
                  PLACE ORDER <span>→</span>
                </button>
                <p className="secure-note">Review your details before ordering.</p>
              </>
            )}
          </aside>
        </section>

        {orders.length > 0 && (
          <section className="recent-orders">
            <div className="section-heading">
              <span className="section-number">03</span>
              <div>
                <h2>Recent orders</h2>
                <p>Your orders placed during this session.</p>
              </div>
            </div>
            {orders.slice(0, 5).map((order) => (
              <div className="recent-order-row" key={order.orderNumber}>
                <div>
                  <strong>{order.orderNumber}</strong>
                  <span>{order.date}</span>
                </div>
                <strong>{money(order.subtotal)}</strong>
                <button
                  className="secondary-button"
                  onClick={() => setReceipt(order)}
                >
                  View receipt
                </button>
              </div>
            ))}
          </section>
        )}
      </main>

      {receipt && (
        <div className="receipt-overlay" role="dialog" aria-modal="true">
          <section className="receipt-card">
            <div className="receipt-top">
              <div className="receipt-logo">
                <img src="/logo.png" alt="Canteen Grab" />
              </div>
              <span className="receipt-status">✓ ORDER CONFIRMED</span>
              <h2>CANTEEN GRAB</h2>
              <p>CAMPUS FOOD ORDER RECEIPT</p>
              <div className="receipt-number">
                <span>ORDER NUMBER</span>
                <strong>{receipt.orderNumber}</strong>
              </div>
            </div>

            <div className="receipt-details">
              <div>
                <span>Customer</span>
                <strong>{receipt.customerName}</strong>
              </div>
              <div>
                <span>Date and time</span>
                <strong>{receipt.date}</strong>
              </div>
              <div>
                <span>Delivery location</span>
                <strong>{receipt.building}, {receipt.floor}</strong>
              </div>
              <div>
                <span>Store</span>
                <strong>{receipt.store}</strong>
              </div>
              <div>
                <span>Payment method</span>
                <strong>{receipt.payment}</strong>
              </div>
            </div>

            <div className="receipt-items">
              <h3>ORDER SUMMARY</h3>
              <div className="receipt-table-head">
                <span>ITEM</span>
                <span>QTY</span>
                <span>AMOUNT</span>
              </div>
              {receipt.items.map((item) => (
                <div className="receipt-item" key={item.id}>
                  <span>{item.name}</span>
                  <span>{item.qty}</span>
                  <strong>{money(item.price * item.qty)}</strong>
                </div>
              ))}
            </div>

            <div className="receipt-totals">
              <div>
                <span>Subtotal</span>
                <strong>{money(receipt.subtotal)}</strong>
              </div>
              <div className="receipt-grand-total">
                <span>TOTAL</span>
                <strong>{money(receipt.subtotal)}</strong>
              </div>
              <div>
                <span>Amount received</span>
                <strong>{money(receipt.amountPaid)}</strong>
              </div>
              <div className="receipt-change">
                <span>
                  {receipt.payment === "Cash" ? "CUSTOMER CHANGE" : "BALANCE DUE"}
                </span>
                <strong>
                  {money(receipt.payment === "Cash" ? receipt.change : 0)}
                </strong>
              </div>
            </div>

            {receipt.instructions && (
              <p className="receipt-note">
                <strong>Instructions:</strong> {receipt.instructions}
              </p>
            )}

            <div className="receipt-footer">
              <strong>THANK YOU FOR YOUR ORDER!</strong>
              <span>Fresh food. Fast service. Campus convenience.</span>
            </div>

            <div className="receipt-actions">
              <button
                className="primary-button"
                onClick={() => window.print()}
              >
                PRINT RECEIPT
              </button>
              <button
                className="secondary-button"
                onClick={() => setReceipt(null)}
              >
                DONE
              </button>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

export default App;