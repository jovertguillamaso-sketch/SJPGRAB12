# Canteen Grab — organized source files

## Structure
- `src/App.jsx` — main app layout and state/handlers (login, cart, checkout, orders, settings, receipt).
- `src/components/ProductImage.jsx` — product image fallback component.
- `src/data/stores.js` — store and product data.
- `src/utils/money.js` — Philippine peso formatter.
- `src/App.css` — CSS entry point; imports the separate stylesheets below.
- `src/styles/global.css` — fonts, CSS variables, reset, and global elements.
- `src/styles/shared.css` — shared buttons and brand elements.
- `src/styles/auth.css` — login and sign-up.
- `src/styles/dashboard.css` — main dashboard and product cards.
- `src/styles/checkout.css` — delivery form and cart.
- `src/styles/orders-settings.css` — settings and recent orders.
- `src/styles/receipt.css` — receipt modal.
- `src/styles/responsive.css` — responsive layout.
- `src/styles/print.css` — print receipt styles.

## Setup
Copy the `src` folder into your existing React project and keep your current `main.jsx`/`index.jsx` entry file. `App.jsx` imports `App.css` and the extracted modules.

Keep product images in `public/products/` and the logo at `public/logo.png`, matching the paths in `src/data/stores.js` and `src/App.jsx`.

## Important behavior note
This is a client-side demo. Accounts, passwords, and orders are stored only in React state and will reset on refresh. The GCash option does not process a real payment. For real deployment, connect authentication and orders to a backend such as Supabase.
